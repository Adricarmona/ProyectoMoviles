package com.example.proyectomoviles.model.dataStore

data class configuracionInterfaz(
    val idioma: String,
    val correosPromocionales: Boolean,
    val correosNoticias: Boolean,
    val terminos: Boolean,
    val privacidad: Boolean,
    val Pagina: Int)
